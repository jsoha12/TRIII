---
title: Battery
categories:
  - Devices
tags:
  - power
  - charge
---
