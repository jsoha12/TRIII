let session = {
  init: function () {
    return new Promise(function (resolve, reject) {
      $.ajax({
        url: "helpers/session.php",
        cache: false,
        method: "post",
        data: {action: "get"},
        dataType: "json",
        success: function (data) {
          session_data = data;
          resolve(data);
        },
        error: function (xhr, status, error) {
          reject(error);
        },
      });
    });
  },
  get: function (name) {
    if (session_data[name] === null || session_data[name] === "") {
      return undefined;
    } else {
      return session_data[name];
    }
  },
  set: function (name, value) {
    return new Promise(function (resolve, reject) {
      $.ajax({
        url: "helpers/session.php",
        cache: false,
        method: "post",
        data: {action: "set", name: name, value: value},
        dataType: "json",
        success: function (data) {
          session_data = data;
          resolve();
        },
        error: function (xhr, status, error) {
          reject(error);
        },
      });
    });
  },
  destroy: function () {
    return new Promise(function (resolve, reject) {
      $.ajax({
        url: "helpers/session.php",
        cache: false,
        method: "post",
        data: {action: "destroy"},
        success: function (data) {
          resolve();
        },
        error: function (xhr, status, error) {
          reject(error);
        },
      });
    });
  },
};

let dbQuery = {
  execute: function (query) {
    return new Promise(function (resolve, reject) {
      $.ajax({
        url: "helpers/db_query.php",
        dataType: "json",
        data: {action: "query", query: query},
        success: function (data) {
          query_result = data;
          resolve();
        },
        error: function (xhr, status, error) {
          reject(error);
        },
      });
    });
  },
  result: function (index, field) {
    if (query_result[index][field] == undefined) {
      return "";
    } else {
      return query_result[index][field];
    }
  },
  rows: function () {
    return query_result.length;
  },
  executeNonQuery: function (query) {
    return new Promise(function (resolve, reject) {
      $.ajax({
        url: "helpers/db_query.php",
        data: {action: "non-query", query: query},
        success: function (data) {
          resolve(data);
        },
        error: function (xhr, status, error) {
          reject(status);
        },
      });
    });
  },
  clear: function () {
    query_result = [];
  },
};

var passTotal = 0;
var listen = false;
var bill = 0;
function logPayment() {
  fetch("http://127.0.0.1:5000/pay")
    .then((response) => response.json())
    .then((data) => (bill = data.denomination));
}

function startlisten(x) {
  listen = x;
  if (x) {
    fetch("http://127.0.0.1:5000/start-listening")
      .then((response) => response.json())
      .then((data) => console.log("Listening status:", data.status))
      .then(() => {
        // Start periodic pulse checking
        const payInterval = setInterval(logPayment, 1500);
      });
  } else {
    clearInterval(payInterval);
  }
}

function addPass(elementId) {
  var element = $("#" + elementId); // Convert ID to jQuery object
  if (passTotal < 6) {
    let sum = parseInt(element.val()) + 1;
    element.val(sum.toString());
    updateTotal(); // Update the total
  }
}

function subPass(elementId) {
  var element = $("#" + elementId); // Convert ID to jQuery object
  if (passTotal > 0) {
    let diff = parseInt(element.val()) - 1;
    element.val(diff.toString());
    updateTotal(); // Update the total
  }
}

function updateTotal() {
  // Update passTotal based on current values of normal, student, and pwd
  passTotal =
    parseInt($("#normal").val()) +
    parseInt($("#student").val()) +
    parseInt($("#pwd").val());
  $("#input-qtytotal").val(passTotal); // Assuming this is your total input field
}

$(document).ready(function () {
  let allRoutes = {};
  let arrQueue = {};

  let cmbRoutes = $("[name='select-routes']");
  let tbldriverQueue = $("[name='driver-queue']");

  let mdlBuy = $("[name='modal-buy'");
  let mdlProceed = $("[name='modal-proceed'");
  let btnProceed = $("[name='btn-proceed']");

  let txtDest = $("[name='input-dest']");
  let txtDriver = $("[name='input-driver']");
  let txtFare = $("[name='input-fare']");
  let txtPayment = $("[name='input-payment']");
  let lblPayment = $("[name='label-payment']");

  txtPayment.val(bill.toString());
  $("#normal").val("0");
  $("#student").val("0");
  $("#pwd").val("0");
  lblPayment.html("Insert payment into the money slots");

  let route_id;
  let driver_id;
  let driver_income;

  session.init().then(function () {
    if (session.get("user_id")) {
      window.location.href = "pages/dashboard/dashboard.php";
    }
    console.log("here");
    dbQuery.execute("Select * From routestbl; ").then(function () {
      if (dbQuery.rows() > 0) {
        allRoutes = query_result;

        for (var i = 0; i < dbQuery.rows(); i++) {
          cmbRoutes.append(
            '<option value="' +
              i +
              '">' +
              dbQuery.result(i, "dest") +
              "</option>"
          );
        }
      }
      console.log(allRoutes);
    });
  });

  cmbRoutes.off("change").on("change", function () {
    // Assuming txtSubjectCode is a valid reference to an input element
    var v = parseInt(cmbRoutes.val()) + 1;
    txtDest.val(allRoutes[cmbRoutes.val()].dest);
    txtFare.val(allRoutes[cmbRoutes.val()].fare);
    route_id = allRoutes[cmbRoutes.val()].id;
    tbldriverQueue.children("tbody").children("tr").remove();
    dbQuery
      .execute(
        'SELECT ridetbl.*, usertbl.fullname FROM ridetbl LEFT JOIN usertbl on usertbl.id = ridetbl.driver WHERE ridetbl.route = "' +
          v +
          '" ORDER BY ridetbl.date'
      )
      .then(function () {
        arrQueue = query_result;
        if (dbQuery.rows() > 0) {
          console.log(dbQuery.result(cmbRoutes.val(), "fullname"));
          console.log(txtDriver.val());
          for (var i = 0; i < dbQuery.rows(); i++) {
            tbldriverQueue
              .children("tbody")
              .append(
                "<tr>" +
                  '<td align="center" valign="middle">' +
                  dbQuery.result(i, "fullname") +
                  "</td>" +
                  "</tr>"
              );
          }
        }
        txtDriver.val(arrQueue[cmbRoutes.val()].fullname);
        driver_id = arrQueue[cmbRoutes.val()].driver;
        driver_income = parseInt(txtFare.val()) - 1;
      });
  });

  btnProceed.click(function () {
    console.log("PROCEED");
    let selectedQueue = arrQueue.find(
      (queue) => parseInt(queue.passenger) + passTotal <= 6
    );

    if (selectedQueue) {
      // Handle the case where a suitable queue is found
      txtDriver.val(selectedQueue.fullname);
      driver_id = selectedQueue.driver;
      driver_income = parseInt(txtFare.val()) - 1;
      // Additional logic to handle the ticket purchase
      if (txtPayment.val() >= txtFare.val()) {
        let ref = Date.now();
        dbQuery
          .executeNonQuery(
            'INSERT INTO salestbl VALUES ( Null, "' +
              txtPayment.val() +
              '", "' +
              route_id +
              '", "' +
              driver_id +
              '", "' +
              driver_income +
              '", "' +
              selectedQueue.id +
              '", "' +
              passTotal +
              '", "' +
              ref +
              '", Default);'
          )
          .then(function () {
            dbQuery
              .executeNonQuery(
                "UPDATE ridetbl SET passenger = passenger + " +
                  passTotal +
                  ' WHERE id = "' +
                  selectedQueue.id +
                  '"'
              )
              .then(function () {
                const data = {
                  // Collect data for printing
                  reference: ref.toString(),
                  stationName: "MSC Tanza Station",
                  driverName: selectedQueue.fullname,
                  passenger: passTotal.toString(),
                  totalFare: txtPayment.val().toString(),
                  timeAndDate: new Date().toLocaleString(),
                };

                fetch("http://127.0.0.1:5000/print", {
                  // Adjust URL for Flask server
                  method: "POST",
                  headers: {"Content-Type": "application/json"},
                  body: JSON.stringify(data),
                })
                  .then((response) => response.json())
                  .then((result) => console.log(result));
              })
              .then(function () {
                passTotal = 0;
                window.location.reload();
              });
          });
      } else {
        lblPayment.html("Not enough payment*");
      }
    } else {
      alert("No Suitable Ride found on queue.");
    }
  });
});
