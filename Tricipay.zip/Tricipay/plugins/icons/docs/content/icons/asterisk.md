---
title: Asterisk
categories:
  - Typography
tags:
  - asterisks
  - star
---
