<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="../bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">

    <div class="d-flex">
        <img class="me-2" src="assets/images/tricipay_icon.png" style="width: 10%;">
        <a href="../index.php" style="text-decoration:none; color:inherit">
            <h1 style="font-style:none; cursor:pointer">Tricipay</h1>
        </a>
    </div>
    </div>

    <script src="../bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
