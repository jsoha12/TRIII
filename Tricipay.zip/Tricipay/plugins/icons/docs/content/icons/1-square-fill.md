---
title: 1 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
